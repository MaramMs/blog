'use client'
import "./globals.css";

import { useLanguage } from "./contexts/LanguageContext";
import NavBar from "./components/NavBar";
import Footer from "./components/Footer";

export default function RootLayoutClient({ children }) {
  const { language } = useLanguage();

  return (
    <div dir={language === 'ar' ? 'rtl' : 'ltr'} lang={language}>
      <NavBar />
      <main>{children}</main>
      <Footer />
    </div>
  );
}
